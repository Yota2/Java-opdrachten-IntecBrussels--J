package be.intecbrussel.eatables;

public interface Eatable {
      default  void eat() {

      }

}