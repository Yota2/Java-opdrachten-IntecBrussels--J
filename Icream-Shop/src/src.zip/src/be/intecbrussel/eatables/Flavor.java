package be.intecbrussel.eatables;

public enum Flavor {

    STRAWBERRY ,
    BANANA ,
    CHOCOLATE,
    VANILLA,
    STRACIATELLA,
    MOKKA,
    PISTACHE;


}
