package be.intecbrussel.sellers;

public interface Profitable {
    double getProfit();
}
