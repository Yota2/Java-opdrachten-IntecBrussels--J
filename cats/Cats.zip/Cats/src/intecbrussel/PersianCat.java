package intecbrussel;

public class PersianCat extends  Felis{

    public PersianCat(String name, int age, int shelterNo, int badgeNo) {
        super(name, age, shelterNo, badgeNo);
    }

    public void miauw(){

    }

}
